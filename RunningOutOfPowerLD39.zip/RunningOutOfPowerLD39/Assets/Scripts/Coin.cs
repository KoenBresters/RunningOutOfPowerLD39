﻿using UnityEngine;

public class Coin : MonoBehaviour
{
    public string audioOnHIt;
    public int points = 1;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            LevelManager.current.score += points;
            Destroy(transform.parent.gameObject);
            AudioManager.current.Play(audioOnHIt);
        }
    }
}
