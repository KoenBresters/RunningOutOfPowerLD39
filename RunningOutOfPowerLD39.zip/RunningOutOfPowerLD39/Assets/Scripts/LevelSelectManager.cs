﻿using UnityEngine;

public class LevelSelectManager : MonoBehaviour {

    public GameObject[] levelButtons;

    public int levelProgress;

    private void Start()
    {
        if (PlayerPrefs.HasKey("LevelProgress"))
        {
            levelProgress = PlayerPrefs.GetInt("LevelProgress");
        }else
        {
            levelProgress = 1;
            PlayerPrefs.SetInt("LevelProgress", 1);
            PlayerPrefs.Save();
        }
        int x = 1;
        foreach (GameObject i in levelButtons)
        {
            if(x > levelProgress)
                i.SetActive(false);
            x++;
        }
    }

}
