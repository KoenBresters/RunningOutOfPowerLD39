﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class LevelManager : MonoBehaviour {

    public static LevelManager current{ get; private set; }
    public int levelNum;
    public Animator anim;
    public Text scoreText;
    public Text levelText;
    public Transform posOfEndCam;

    public Obsticle[] obsticles;
    [HideInInspector]
    public int score = 0;

    [Header("diffferent per level")]
    public Dictionary<Color, GameObject> obsticleDict;

    private void Awake()
    {
        current = this;
        obsticleDict = new Dictionary<Color, GameObject>();
        foreach (Obsticle i in obsticles)
        {
            obsticleDict.Add(i.color, i.prefab);
        }
    }

    [System.Serializable]
    public class Obsticle
    {
        public Color color;
        public GameObject prefab;
    }


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneFader.current.FadeTo("LevelSelect");
        }
    }
    public void endLevel()
    {
        SceneFader.current.reLoadSceneFaded();
    }

    public void WinLevel()
    {
        scoreText.text = "score: " + score.ToString();
        levelText.text = "Level " + levelNum.ToString() + " completed";
        if (!PlayerPrefs.HasKey("LevelProgress"))
            PlayerPrefs.SetInt("LevelProgress", 1);
        if (PlayerPrefs.GetInt("LevelProgress") <= levelNum)
            PlayerPrefs.SetInt("LevelProgress", levelNum + 1);
        PlayerPrefs.Save();
        anim.SetBool("Open", true);
        Player.current.speed = 0;
        Camera.main.transform.position = posOfEndCam.position;
        Camera.main.transform.rotation = posOfEndCam.rotation;
        Player.current.isFalling = false;
    }
}
