﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneFader : MonoBehaviour {

    public Image fadeImage;
    public AnimationCurve curve;
    public static SceneFader current;

    private void Awake()
    {
        current = this;
    }

    void Start()
    {
        StartCoroutine(fadeIn());
    }

    public IEnumerator fadeIn()
    {
        float t = 1f;
        while (t > 0f)
        {
            t -= Time.deltaTime;
            fadeImage.color = new Color(fadeImage.color.r, fadeImage.color.g, fadeImage.color.b, curve.Evaluate(t));
            yield return 0;
        }
    }

    public IEnumerator fadeOut(string scene)
    {
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime;
            fadeImage.color = new Color(fadeImage.color.r, fadeImage.color.g, fadeImage.color.b, curve.Evaluate(t));
            yield return 0;
        }
        SceneManager.LoadScene(scene);
    }

    public void FadeTo(string scene)
    {
        StartCoroutine(fadeOut(scene));
    }

    public void reLoadSceneFaded()
    {
        FadeTo(SceneManager.GetActiveScene().name);
    }

}
