﻿using UnityEngine;

public class HitWin : MonoBehaviour
{
    public string audioOnHIt;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            LevelManager.current.WinLevel();
            AudioManager.current.Play(audioOnHIt);
            AudioManager.current.Music = "-1";
        }
    }
}
