﻿using UnityEngine;

public class Portal : MonoBehaviour {

    public Cable teleportCable;
    public float teleportProgress;
    public string audioOnHIt;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            Player.current.currentCable = teleportCable;
            Player.current.progress = teleportProgress;
            AudioManager.current.Play(audioOnHIt);
        }
    }
}
