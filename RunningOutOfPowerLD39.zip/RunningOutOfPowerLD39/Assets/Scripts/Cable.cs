﻿using UnityEngine;

public class Cable : MonoBehaviour {

    public Cable next;
    public Texture2D input;
    private Player player;

    public Vector3 forwardPoint;
    public Vector3 endPoint;
    [HideInInspector]
    public float length;
    [HideInInspector]
    public Vector3 realForwardPoint;
    [HideInInspector]
    public Vector3 realEndPoint;

    private void Awake()
    {
        length = Vector3.Distance(transform.TransformPoint(forwardPoint), transform.TransformPoint(endPoint));
        realForwardPoint = transform.TransformPoint(forwardPoint);
        realEndPoint = transform.TransformPoint(endPoint);
    }

    private void Start()
    {
        for (int i = 0; i < input.height; i++)
        {
            for (int j = 0; j < input.width; j++)
            {
                Color p = input.GetPixel(j, i);
                if (LevelManager.current.obsticleDict.ContainsKey(p))
                {
                    Transform a = Instantiate(LevelManager.current.obsticleDict[p]).transform;
                    a.forward = transform.forward;
                    a.position = Vector3.Lerp(realForwardPoint, realEndPoint, i / (float)input.height);
                    a.Rotate(Quaternion.AngleAxis(Mathf.Lerp(-180, 180, j / (float)input.width), Vector3.forward).eulerAngles);
                }
            }
        }
    }


    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawCube(transform.TransformPoint(forwardPoint), Vector3.one * 0.3f);
        Gizmos.color = Color.red;
        Gizmos.DrawCube(transform.TransformPoint(endPoint), Vector3.one * 0.3f);
    }

}
