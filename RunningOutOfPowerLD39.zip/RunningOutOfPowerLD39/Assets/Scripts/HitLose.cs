﻿using UnityEngine;

public class HitLose : MonoBehaviour {
    public string audioOnHIt;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            LevelManager.current.endLevel();
            AudioManager.current.Play(audioOnHIt);
        }
    }
}
