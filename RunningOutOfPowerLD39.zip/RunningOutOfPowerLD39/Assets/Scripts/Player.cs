﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    public static Player current;
    public Cable currentCable;
    public float speed;
    public float rotationSpeed;
    public float progress;
    private float rotation;
    public bool isFalling = false;
    private float Rotation
    {
        get{ return rotation; }
        set { rotation = value; if (rotation < 0) rotation += 360; if (rotation > 360) rotation -= 360; }
    }

    private void Awake()
    {
        current = this;
    }

    // Update is called once per frame
    void Update () {
        Debug.DrawRay(transform.position, currentCable.transform.forward * 100f);
        if (isFalling) return;
        progress += speed * Time.deltaTime;
        if (Input.GetKey(KeyCode.A))
        {
            Rotation += rotationSpeed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            Rotation -= rotationSpeed * Time.deltaTime;
        }
        transform.forward = currentCable.transform.forward;
        transform.position = Vector3.Lerp(currentCable.realForwardPoint, currentCable.realEndPoint, progress / currentCable.length);
        transform.Rotate(Quaternion.AngleAxis(rotation, Vector3.forward).eulerAngles);
        if(progress >= currentCable.length)
        {
            if(currentCable.next == null)
            {
                GetComponent<Rigidbody>().isKinematic = false;
                GetComponent<Rigidbody>().AddRelativeForce(Vector3.forward * 100, ForceMode.Impulse);
                StartCoroutine(endAfterFall());
                isFalling = true;
                return;
            }
            currentCable = currentCable.next;
            progress = 0;
        }
	}

    public IEnumerator endAfterFall()
    {
        yield return new WaitForSeconds(3f);
        LevelManager.current.endLevel();
    }
}
